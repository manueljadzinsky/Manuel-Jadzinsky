@echo off
REM Lanzador de la API de precipitacion (antecedente 3 dias + pronostico 7 dias)
cd /d "%~dp0"
echo Iniciando la API de precipitacion...
echo Se abrira el panel en el navegador. Cerrar esta ventana detiene el servicio.
python lluvia_api.py --puerto 8766
pause
