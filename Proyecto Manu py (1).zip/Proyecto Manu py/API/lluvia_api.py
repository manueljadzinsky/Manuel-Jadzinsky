# -*- coding: utf-8 -*-
"""
API de precipitación para el Modelo Expeditivo (nivel del lago).

Entrega, para cualquier ubicación geográfica de Argentina:
  - Lluvia acumulada de los ÚLTIMOS 3 DÍAS (72 h móviles) -> condición antecedente.
  - Lluvia PRONOSTICADA para los PRÓXIMOS 7 DÍAS, acumulada por horizonte
    (24 h, 48 h, 72 h, 5 días, 7 días) y desagregada día por día.

Fuente de datos: Open-Meteo (https://open-meteo.com) - gratuita, sin API key.
El pronóstico usa el blend "best_match" (ECMWF / ICON / GFS según escala).

Uso:
    python lluvia_api.py                  # levanta el servidor y abre el panel
    python lluvia_api.py --puerto 8766
    python lluvia_api.py --no-abrir

Endpoints (todos GET salvo aclaración, responden JSON):
    /api/salud
    /api/sitios
    /api/buscar?q=campana
    /api/precipitacion?sitio=puertos_escobar
    /api/precipitacion?lat=-34.378&lon=-58.718
    /api/precipitacion?lugar=Campana
    /api/cuenca?cuenca=lujan
    /api/modelos?sitio=puertos_escobar
"""

from __future__ import annotations

import argparse
import math
import os
import threading
import time
import unicodedata
import webbrowser
from datetime import datetime, timedelta, timezone

import requests
from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS

# ---------------------------------------------------------------------------
# Configuración
# ---------------------------------------------------------------------------
AQUI = os.path.dirname(os.path.abspath(__file__))

API_FORECAST = "https://api.open-meteo.com/v1/forecast"
API_GEOCODING = "https://geocoding-api.open-meteo.com/v1/search"

ZONA = "America/Argentina/Buenos_Aires"

HORIZONTES_DEF = (24, 48, 72, 120, 168)   # horas: 24h, 48h, 72h, 5 días, 7 días
HORAS_ANTECEDENTE = 72                    # "últimos 3 días"
TTL_CACHE_S = 900                         # 15 minutos
TIMEOUT_S = 25

MODELOS_COMPARACION = ("ecmwf_ifs025", "gfs_seamless", "icon_seamless")

# Umbrales (heurísticos, ajustables) para sugerir la condición antecedente
# que consume el Modelo Expeditivo a partir de la lluvia de los últimos 3 días.
UMBRAL_HUMEDO_MM = 15.0
UMBRAL_SATURADO_MM = 50.0

# ---------------------------------------------------------------------------
# Catálogo de sitios (AMBA + cuenca del río Luján)
# ---------------------------------------------------------------------------
SITIOS = {
    "puertos_escobar":   {"nombre": "Puertos / Lago - Escobar", "lat": -34.3780, "lon": -58.7180},
    "escobar":           {"nombre": "Belén de Escobar",         "lat": -34.3460, "lon": -58.7940},
    "capilla_del_senor": {"nombre": "Capilla del Señor",        "lat": -34.2900, "lon": -59.1000},
    "campana":           {"nombre": "Campana",                  "lat": -34.1630, "lon": -58.9590},
    "zarate":            {"nombre": "Zárate",                   "lat": -34.0960, "lon": -59.0240},
    "pilar":             {"nombre": "Pilar",                    "lat": -34.4590, "lon": -58.9140},
    "lujan":             {"nombre": "Luján",                    "lat": -34.5660, "lon": -59.1150},
    "mercedes":          {"nombre": "Mercedes",                 "lat": -34.6510, "lon": -59.4300},
    "gral_rodriguez":    {"nombre": "General Rodríguez",        "lat": -34.6080, "lon": -58.9500},
    "moreno":            {"nombre": "Moreno",                   "lat": -34.6530, "lon": -58.7900},
    "jose_c_paz":        {"nombre": "José C. Paz",              "lat": -34.5220, "lon": -58.7570},
    "tigre":             {"nombre": "Tigre",                    "lat": -34.4260, "lon": -58.5800},
    "san_fernando":      {"nombre": "San Fernando",             "lat": -34.4420, "lon": -58.5600},
    "san_isidro":        {"nombre": "San Isidro",               "lat": -34.4720, "lon": -58.5130},
    "caba":              {"nombre": "Ciudad de Buenos Aires",   "lat": -34.6130, "lon": -58.3770},
    "ezeiza":            {"nombre": "Ezeiza",                   "lat": -34.8200, "lon": -58.5360},
    "la_plata":          {"nombre": "La Plata",                 "lat": -34.9210, "lon": -57.9540},
}

# Puntos que representan la cuenca (promedio areal aproximado por puntos).
CUENCAS = {
    "lujan": {
        "nombre": "Cuenca del río Luján",
        "sitios": ["mercedes", "lujan", "gral_rodriguez", "pilar", "moreno",
                   "jose_c_paz", "escobar", "capilla_del_senor", "puertos_escobar"],
    },
    "amba_norte": {
        "nombre": "AMBA norte",
        "sitios": ["escobar", "pilar", "tigre", "san_fernando", "san_isidro", "campana"],
    },
}


# ---------------------------------------------------------------------------
# Cache en memoria
# ---------------------------------------------------------------------------
class Cache:
    def __init__(self, ttl):
        self.ttl = ttl
        self._d = {}
        self._lock = threading.Lock()

    def get(self, clave):
        with self._lock:
            item = self._d.get(clave)
            if not item:
                return None
            ts, valor = item
            if time.time() - ts > self.ttl:
                self._d.pop(clave, None)
                return None
            return valor

    def set(self, clave, valor):
        with self._lock:
            self._d[clave] = (time.time(), valor)

    def limpiar(self):
        with self._lock:
            self._d.clear()


CACHE = Cache(TTL_CACHE_S)


# ---------------------------------------------------------------------------
# Utilidades
# ---------------------------------------------------------------------------
def _sin_tildes(s):
    s = unicodedata.normalize("NFKD", str(s))
    return "".join(c for c in s if not unicodedata.combining(c)).lower().strip()


def _r1(x):
    """Redondeo a 1 decimal, tolerante a None."""
    if x is None:
        return None
    return round(float(x), 1)


def _ahora_local(offset_seg):
    """'Ahora' expresado en la hora local del sitio, como datetime naive."""
    return (datetime.now(timezone.utc) + timedelta(seconds=offset_seg)).replace(tzinfo=None)


def _parse_horas(lista):
    return [datetime.strptime(t, "%Y-%m-%dT%H:%M") for t in lista]


def _acumular(tiempos, valores, desde, hasta):
    """
    Suma la precipitación horaria en el intervalo (desde, hasta].
    En Open-Meteo el valor horario corresponde a la hora PRECEDENTE al timestamp,
    por eso el intervalo es abierto por izquierda y cerrado por derecha.
    """
    total = 0.0
    for t, v in zip(tiempos, valores):
        if v is None:
            continue
        if desde < t <= hasta:
            total += float(v)
    return total


def _etiqueta_horizonte(h):
    if h < 96:
        return "%d h" % h
    d = h / 24.0
    return "%g días" % (round(d, 1) if d % 1 else int(d))


def _condicion_antecedente(mm_72h):
    """Sugerencia de estado antecedente para el modelo (heurística, ajustable)."""
    if mm_72h is None:
        return None
    if mm_72h < UMBRAL_HUMEDO_MM:
        return "Seco"
    if mm_72h < UMBRAL_SATURADO_MM:
        return "Húmedo"
    return "Saturado"


class ErrorAPI(Exception):
    def __init__(self, mensaje, codigo=400):
        super().__init__(mensaje)
        self.mensaje = mensaje
        self.codigo = codigo


# ---------------------------------------------------------------------------
# Acceso a Open-Meteo
# ---------------------------------------------------------------------------
def _pedir_forecast(lats, lons, horas_pasado, horas_futuro, modelos=None):
    """
    Devuelve (lista_de_bloques, cacheado). Siempre una lista, un bloque por coordenada.
    """
    dias_pasado = int(math.ceil(horas_pasado / 24.0))
    dias_futuro = min(16, int(math.ceil(horas_futuro / 24.0)) + 1)

    params = {
        "latitude": ",".join("%.4f" % v for v in lats),
        "longitude": ",".join("%.4f" % v for v in lons),
        "hourly": "precipitation",
        "daily": "precipitation_sum,precipitation_probability_max",
        "past_days": dias_pasado,
        "forecast_days": dias_futuro,
        "timezone": ZONA,
    }
    if modelos:
        params["models"] = ",".join(modelos)

    clave = ("fc", params["latitude"], params["longitude"],
             dias_pasado, dias_futuro, params.get("models", ""))
    cacheado = CACHE.get(clave)
    if cacheado is not None:
        return cacheado, True

    try:
        resp = requests.get(API_FORECAST, params=params, timeout=TIMEOUT_S)
    except requests.RequestException as e:
        raise ErrorAPI("No se pudo contactar el servicio meteorológico: %s" % e, 503)

    if resp.status_code != 200:
        try:
            detalle = resp.json().get("reason", "")
        except Exception:
            detalle = resp.text[:200]
        raise ErrorAPI("El servicio meteorológico respondió %d. %s"
                       % (resp.status_code, detalle), 502)

    datos = resp.json()
    bloques = datos if isinstance(datos, list) else [datos]
    CACHE.set(clave, bloques)
    return bloques, False


def buscar_lugar(consulta, cantidad=8):
    """Geocodificación restringida a Argentina."""
    clave = ("geo", _sin_tildes(consulta), cantidad)
    cacheado = CACHE.get(clave)
    if cacheado is not None:
        return cacheado

    try:
        resp = requests.get(
            API_GEOCODING,
            params={"name": consulta, "count": 20, "language": "es"},
            timeout=TIMEOUT_S,
        )
        resp.raise_for_status()
    except requests.RequestException as e:
        raise ErrorAPI("No se pudo consultar el geocodificador: %s" % e, 503)

    salida = []
    for r in (resp.json().get("results") or []):
        if r.get("country_code") != "AR":
            continue
        salida.append({
            "nombre": r.get("name"),
            "provincia": r.get("admin1"),
            "partido": r.get("admin2"),
            "lat": round(r["latitude"], 4),
            "lon": round(r["longitude"], 4),
            "fuente": "geocoding",
        })
        if len(salida) >= cantidad:
            break

    CACHE.set(clave, salida)
    return salida


# ---------------------------------------------------------------------------
# Resolución de ubicación a partir de los parámetros del request
# ---------------------------------------------------------------------------
def resolver_ubicacion(args):
    """
    Acepta, en orden de prioridad:
      lat & lon  |  sitio=<clave>  |  lugar=<texto libre>
    Devuelve dict {nombre, lat, lon, fuente}.
    """
    lat, lon = args.get("lat"), args.get("lon")
    if lat is not None and lon is not None:
        try:
            lat, lon = float(lat), float(lon)
        except (TypeError, ValueError):
            raise ErrorAPI("lat/lon deben ser números decimales.")
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            raise ErrorAPI("lat/lon fuera de rango.")
        return {
            "nombre": args.get("nombre") or "%.4f, %.4f" % (lat, lon),
            "lat": lat, "lon": lon, "fuente": "coordenadas",
        }

    sitio = args.get("sitio")
    if sitio:
        s = SITIOS.get(_sin_tildes(sitio).replace(" ", "_"))
        if not s:
            raise ErrorAPI("Sitio desconocido: '%s'. Consulte /api/sitios." % sitio, 404)
        return {"nombre": s["nombre"], "lat": s["lat"], "lon": s["lon"], "fuente": "catálogo"}

    lugar = args.get("lugar")
    if lugar:
        # 1) coincidencia contra el catálogo propio (más confiable para el AMBA)
        objetivo = _sin_tildes(lugar)
        for clave, s in SITIOS.items():
            if objetivo == clave or objetivo in _sin_tildes(s["nombre"]):
                return {"nombre": s["nombre"], "lat": s["lat"], "lon": s["lon"],
                        "fuente": "catálogo"}
        # 2) geocodificador
        res = buscar_lugar(lugar, cantidad=1)
        if not res:
            raise ErrorAPI("No se encontró '%s' en Argentina. Pruebe con lat/lon." % lugar, 404)
        r = res[0]
        etiqueta = r["nombre"] + (", %s" % r["provincia"] if r.get("provincia") else "")
        return {"nombre": etiqueta, "lat": r["lat"], "lon": r["lon"], "fuente": "geocoding"}

    # Por defecto: el sitio del proyecto
    s = SITIOS["puertos_escobar"]
    return {"nombre": s["nombre"], "lat": s["lat"], "lon": s["lon"], "fuente": "por defecto"}


def _horizontes_pedidos(args):
    crudo = args.get("horizontes")
    if not crudo:
        return list(HORIZONTES_DEF)
    try:
        hs = sorted({int(x) for x in crudo.replace(" ", "").split(",") if x})
    except ValueError:
        raise ErrorAPI("horizontes debe ser una lista de horas separadas por comas, "
                       "por ejemplo: 24,48,72,120,168")
    if not hs or min(hs) < 1 or max(hs) > 360:
        raise ErrorAPI("Los horizontes deben estar entre 1 y 360 horas.")
    return hs


# ---------------------------------------------------------------------------
# Armado de la respuesta
# ---------------------------------------------------------------------------
def armar_reporte(bloque, horizontes, horas_antecedente=HORAS_ANTECEDENTE):
    """Convierte un bloque crudo de Open-Meteo en el reporte que consume el modelo."""
    offset = bloque.get("utc_offset_seconds", -10800)
    ahora = _ahora_local(offset)
    # 'corte' = última hora cerrada; el pasado se acumula hasta ahí y el futuro desde ahí.
    corte = ahora.replace(minute=0, second=0, microsecond=0)

    tiempos = _parse_horas(bloque["hourly"]["time"])
    lluvia = bloque["hourly"]["precipitation"]

    # --- pasado: últimas N horas móviles ---
    acum_ant = _acumular(tiempos, lluvia, corte - timedelta(hours=horas_antecedente), corte)
    ant_24 = _acumular(tiempos, lluvia, corte - timedelta(hours=24), corte)
    ant_48 = _acumular(tiempos, lluvia, corte - timedelta(hours=48), corte)

    # --- futuro: acumulados por horizonte ---
    hz = []
    for h in horizontes:
        fin = corte + timedelta(hours=h)
        hz.append({
            "clave": "%dh" % h,
            "etiqueta": _etiqueta_horizonte(h),
            "horas": h,
            "hasta": fin.strftime("%Y-%m-%dT%H:%M"),
            "acumulado_mm": _r1(_acumular(tiempos, lluvia, corte, fin)),
        })

    # --- series diarias (calendario) ---
    d_fechas = bloque["daily"]["time"]
    d_mm = bloque["daily"]["precipitation_sum"]
    d_prob = bloque["daily"].get("precipitation_probability_max") or [None] * len(d_fechas)
    hoy = corte.date().isoformat()

    dias_pasados, dias_futuros = [], []
    for f, mm, p in zip(d_fechas, d_mm, d_prob):
        fila = {"fecha": f, "mm": _r1(mm), "prob_max_pct": p}
        if f < hoy:
            dias_pasados.append(fila)
        else:
            fila["es_hoy"] = (f == hoy)
            dias_futuros.append(fila)

    dias_pasados = dias_pasados[-int(math.ceil(horas_antecedente / 24.0)):]
    dias_futuros = dias_futuros[:8]

    max_h = max(horizontes)
    return {
        "generado": ahora.strftime("%Y-%m-%dT%H:%M:%S"),
        "hora_corte": corte.strftime("%Y-%m-%dT%H:%M"),
        "zona_horaria": bloque.get("timezone", ZONA),
        "punto_grilla": {
            "lat": bloque.get("latitude"),
            "lon": bloque.get("longitude"),
            "elevacion_m": bloque.get("elevation"),
        },
        "antecedente": {
            "ventana_h": horas_antecedente,
            "acumulado_mm": _r1(acum_ant),
            "acum_24h_mm": _r1(ant_24),
            "acum_48h_mm": _r1(ant_48),
            "condicion_sugerida": _condicion_antecedente(acum_ant),
            "dias": dias_pasados,
        },
        "pronostico": {
            "horizonte_max_h": max_h,
            "acumulado_total_mm": _r1(_acumular(
                tiempos, lluvia, corte, corte + timedelta(hours=max_h))),
            "horizontes": hz,
            "dias": dias_futuros,
        },
    }


def _promediar_dias(listas):
    """Promedia series diarias de varios puntos (misma grilla de fechas)."""
    if not listas:
        return []
    n = float(len(listas))
    salida = []
    for i, base in enumerate(listas[0]):
        mm = [l[i]["mm"] for l in listas if i < len(l) and l[i]["mm"] is not None]
        probs = [l[i].get("prob_max_pct") for l in listas
                 if i < len(l) and l[i].get("prob_max_pct") is not None]
        fila = {"fecha": base["fecha"],
                "mm": _r1(sum(mm) / n) if mm else None,
                "prob_max_pct": max(probs) if probs else None}
        if "es_hoy" in base:
            fila["es_hoy"] = base["es_hoy"]
        salida.append(fila)
    return salida


def _meta(cacheado, extra=None):
    m = {
        "fuente": "Open-Meteo (open-meteo.com)",
        "modelo": "best_match (ECMWF / ICON / GFS según escala)",
        "cacheado": bool(cacheado),
        "ttl_cache_s": TTL_CACHE_S,
        "nota_pasado": ("La lluvia de los últimos días proviene del análisis del modelo, "
                        "no de un pluviómetro en sitio. Si hay dato medido en planta, "
                        "usarlo con prioridad."),
    }
    if extra:
        m.update(extra)
    return m


# ---------------------------------------------------------------------------
# Aplicación Flask
# ---------------------------------------------------------------------------
app = Flask(__name__, static_folder=None)
CORS(app)


@app.errorhandler(ErrorAPI)
def _manejar_error_api(e):
    return jsonify({"ok": False, "error": e.mensaje}), e.codigo


@app.errorhandler(Exception)
def _manejar_error(e):
    return jsonify({"ok": False, "error": "Error interno: %s" % e}), 500


@app.get("/")
def raiz():
    if os.path.exists(os.path.join(AQUI, "Panel_Lluvia.html")):
        return send_from_directory(AQUI, "Panel_Lluvia.html")
    return jsonify({"ok": True, "mensaje": "API de precipitación activa.",
                    "endpoints": ["/api/salud", "/api/sitios", "/api/buscar?q=",
                                  "/api/precipitacion", "/api/cuenca", "/api/modelos"]})


@app.get("/api/salud")
def salud():
    return jsonify({"ok": True, "servicio": "precipitación", "version": "1.0",
                    "zona_horaria": ZONA,
                    "hora_local": _ahora_local(-10800).strftime("%Y-%m-%dT%H:%M:%S")})


@app.get("/api/sitios")
def listar_sitios():
    return jsonify({
        "ok": True,
        "sitios": [dict(clave=k, **v) for k, v in SITIOS.items()],
        "cuencas": [{"clave": k, "nombre": v["nombre"], "puntos": len(v["sitios"])}
                    for k, v in CUENCAS.items()],
    })


@app.get("/api/buscar")
def buscar():
    q = (request.args.get("q") or "").strip()
    if len(q) < 3:
        raise ErrorAPI("Indique al menos 3 caracteres en 'q'.")
    catalogo = [{"nombre": v["nombre"], "lat": v["lat"], "lon": v["lon"],
                 "provincia": "Buenos Aires", "fuente": "catálogo", "clave": k}
                for k, v in SITIOS.items() if _sin_tildes(q) in _sin_tildes(v["nombre"])]
    return jsonify({"ok": True, "resultados": catalogo + buscar_lugar(q)})


@app.get("/api/precipitacion")
def precipitacion():
    ubic = resolver_ubicacion(request.args)
    horizontes = _horizontes_pedidos(request.args)
    try:
        h_ant = int(request.args.get("antecedente_h", HORAS_ANTECEDENTE))
    except ValueError:
        raise ErrorAPI("antecedente_h debe ser un entero de horas.")
    if not (1 <= h_ant <= 240):
        raise ErrorAPI("antecedente_h debe estar entre 1 y 240 horas.")

    bloques, cacheado = _pedir_forecast([ubic["lat"]], [ubic["lon"]],
                                        h_ant, max(horizontes))
    rep = armar_reporte(bloques[0], horizontes, h_ant)
    return jsonify(dict({"ok": True, "ubicacion": ubic}, **rep, meta=_meta(cacheado)))


@app.get("/api/cuenca")
def cuenca():
    """Promedio areal por puntos: lo que realmente alimenta al lago."""
    clave = _sin_tildes(request.args.get("cuenca") or "lujan").replace(" ", "_")
    c = CUENCAS.get(clave)
    if not c:
        raise ErrorAPI("Cuenca desconocida: '%s'. Opciones: %s"
                       % (clave, ", ".join(CUENCAS)), 404)

    horizontes = _horizontes_pedidos(request.args)
    puntos = [SITIOS[s] for s in c["sitios"]]
    bloques, cacheado = _pedir_forecast([p["lat"] for p in puntos],
                                        [p["lon"] for p in puntos],
                                        HORAS_ANTECEDENTE, max(horizontes))

    detalle, reportes = [], []
    for p, b in zip(puntos, bloques):
        r = armar_reporte(b, horizontes)
        reportes.append(r)
        detalle.append({
            "nombre": p["nombre"], "lat": p["lat"], "lon": p["lon"],
            "antecedente_mm": r["antecedente"]["acumulado_mm"],
            "horizontes_mm": {h["clave"]: h["acumulado_mm"]
                              for h in r["pronostico"]["horizontes"]},
        })

    n = float(len(reportes))
    prom_ant = sum(r["antecedente"]["acumulado_mm"] for r in reportes) / n
    hz_prom = []
    for i, h in enumerate(horizontes):
        vals = [r["pronostico"]["horizontes"][i]["acumulado_mm"] for r in reportes]
        hz_prom.append({
            "clave": "%dh" % h, "etiqueta": _etiqueta_horizonte(h), "horas": h,
            "hasta": reportes[0]["pronostico"]["horizontes"][i]["hasta"],
            "acumulado_mm": _r1(sum(vals) / n),
            "minimo_mm": _r1(min(vals)), "maximo_mm": _r1(max(vals)),
        })

    dias_ant = _promediar_dias([r["antecedente"]["dias"] for r in reportes])
    dias_pro = _promediar_dias([r["pronostico"]["dias"] for r in reportes])

    return jsonify({
        "ok": True,
        "cuenca": {"clave": clave, "nombre": c["nombre"], "puntos": int(n)},
        "generado": reportes[0]["generado"],
        "hora_corte": reportes[0]["hora_corte"],
        "zona_horaria": reportes[0]["zona_horaria"],
        "antecedente": {"ventana_h": HORAS_ANTECEDENTE,
                        "acumulado_mm": _r1(prom_ant),
                        "condicion_sugerida": _condicion_antecedente(prom_ant),
                        "dias": dias_ant},
        "pronostico": {"horizonte_max_h": max(horizontes),
                       "acumulado_total_mm": hz_prom[-1]["acumulado_mm"],
                       "horizontes": hz_prom,
                       "dias": dias_pro},
        "detalle_puntos": detalle,
        "meta": _meta(cacheado, {"metodo": "promedio aritmético de %d puntos" % n}),
    })


@app.get("/api/modelos")
def modelos():
    """Dispersión entre modelos: banda de incertidumbre de la lluvia pronosticada."""
    ubic = resolver_ubicacion(request.args)
    horizontes = _horizontes_pedidos(request.args)
    bloques, cacheado = _pedir_forecast([ubic["lat"]], [ubic["lon"]],
                                        HORAS_ANTECEDENTE, max(horizontes),
                                        modelos=MODELOS_COMPARACION)
    b = bloques[0]
    offset = b.get("utc_offset_seconds", -10800)
    corte = _ahora_local(offset).replace(minute=0, second=0, microsecond=0)
    tiempos = _parse_horas(b["hourly"]["time"])

    por_modelo = {}
    for m in MODELOS_COMPARACION:
        serie = b["hourly"].get("precipitation_%s" % m)
        if not serie:
            continue
        por_modelo[m] = {
            "horizontes_mm": {
                "%dh" % h: _r1(_acumular(tiempos, serie, corte, corte + timedelta(hours=h)))
                for h in horizontes
            }
        }

    banda = {}
    for h in horizontes:
        k = "%dh" % h
        vals = [v["horizontes_mm"][k] for v in por_modelo.values()
                if v["horizontes_mm"].get(k) is not None]
        if vals:
            banda[k] = {"min_mm": _r1(min(vals)),
                        "medio_mm": _r1(sum(vals) / len(vals)),
                        "max_mm": _r1(max(vals))}

    return jsonify({"ok": True, "ubicacion": ubic,
                    "hora_corte": corte.strftime("%Y-%m-%dT%H:%M"),
                    "modelos": por_modelo, "banda": banda,
                    "meta": _meta(cacheado, {"modelo": ", ".join(MODELOS_COMPARACION)})})


@app.post("/api/cache/limpiar")
def limpiar_cache():
    CACHE.limpiar()
    return jsonify({"ok": True, "mensaje": "Cache vaciada."})


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="API de precipitación - Modelo Expeditivo")
    ap.add_argument("--puerto", type=int, default=8766)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--no-abrir", action="store_true", help="no abrir el navegador")
    args = ap.parse_args()

    url = "http://%s:%d" % (args.host, args.puerto)
    print("API de precipitacion corriendo en %s" % url)
    print("  %s/api/precipitacion?sitio=puertos_escobar" % url)
    print("  %s/api/cuenca?cuenca=lujan" % url)
    print("Ctrl+C para detener.")

    if not args.no_abrir:
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()

    try:
        from waitress import serve
        serve(app, host=args.host, port=args.puerto, threads=8)
    except ImportError:
        app.run(host=args.host, port=args.puerto, debug=False)


if __name__ == "__main__":
    main()
