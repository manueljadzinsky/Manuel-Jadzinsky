@echo off
REM Lanzador del Modelo Expeditivo (front-end + backend Excel)
cd /d "%~dp0"
echo Iniciando el modelo... se abrira Excel de fondo y luego el navegador.
python backend_server.py
pause
