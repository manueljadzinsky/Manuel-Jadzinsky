# -*- coding: utf-8 -*-
"""
Backend local para el Modelo Operativo Expeditivo - Puertos (V4).

Usa el propio Excel como motor de cálculo (vía COM / pywin32):
  - Al arrancar copia el .xlsx a una carpeta temporal (para NO bloquear el
    original en OneDrive) y abre Excel oculto una sola vez.
  - Por cada request escribe las entradas de la hoja "Modelo", recalcula y
    lee los indicadores, la proyección de 7 días y la lectura del escenario.

Uso:
    python backend_server.py
Luego abrir en el navegador:  http://127.0.0.1:8765

Endpoints:
    GET  /            -> sirve Panel_Puertos_V4_Estatico.html
    GET  /model       -> estado actual del modelo (entradas + resultados)
    POST /calculate   -> recalcula con las entradas enviadas
    POST /reload      -> vuelve a copiar el Excel original y reabre
"""

import os
import sys
import shutil
import tempfile
import json
import datetime
import http.server
import socketserver
import webbrowser

import pythoncom
import win32com.client as win32

# ----------------------------------------------------------------------------
# Configuración
# ----------------------------------------------------------------------------
EMPAQUETADO = getattr(sys, "frozen", False)   # True cuando corre como .exe


def recurso(nombre):
    """Ruta de un archivo que viaja con el programa.

    Empaquetado con PyInstaller, el Excel y el HTML se extraen a una carpeta
    temporal propia de cada ejecución (sys._MEIPASS) que se borra al salir;
    sin empaquetar, salen de la carpeta del script.
    """
    base = getattr(sys, "_MEIPASS", None) or os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, nombre)


HERE = getattr(sys, "_MEIPASS", None) or os.path.dirname(os.path.abspath(__file__))
SRC_XLSX = recurso("Modelo_Simplificado_Evaluacion_Exposicion_Hidrica.xlsx")
PAGE = "Panel_Puertos_V4.html"   # panel interactivo (el _Estatico es la maqueta original)

SHEET = "Modelo"        # hoja de entradas y resultados
SHEET_CALC = "Calculo"  # hoja de cálculo interno (P5d y CER)
SHEET_PARAM = "Parametros"  # hoja de parámetros técnicos

HOST = "127.0.0.1"
PORT = 8765

DIAS_ANTECEDENTES = 5   # Día -5 .. Día -1  -> B9:B13
DIAS_PRONOSTICO = 7     # Día 1 .. Día 7    -> filas 19..25

# --- Entradas (hoja "Modelo") ---
CELL_NIVEL = "B6"            # Nivel actual del lago (m IGN)
ROW_ANTECEDENTE_0 = 9        # B9..B13  precipitación antecedente (mm)
CELL_SIN_DESCARGA = "B14"    # "NO" / "SÍ"
ROW_PRONOSTICO_0 = 19        # B19..B25 lluvia (mm) y C19..C25 Río Luján (m IGN)

# --- Indicadores (hoja "Modelo") ---
OUT_INDICADORES = {
    "capacidad_fisica_cm":     "F6",   # Capacidad física actual (cm)
    "lluvia_hasta_critica_mm": "H6",   # Lluvia hasta condición crítica (mm)
    "estado_inicial":          "G10",  # NORMAL / ATENCIÓN / ACCIÓN PREVENTIVA / CRÍTICO
}

# --- Información operativa (hoja "Parametros") ---
OUT_PARAMETROS = {
    "cota_critica":        "B6",   # Cota crítica de referencia (m IGN)
    "activacion_descarga": "B8",   # Cota de activación de compuerta (m IGN)
    "limite_modelo":       "B19",  # Límite superior de validez (m IGN)
}

# --- Lectura del escenario (hoja "Modelo") ---
# Ojo: B29 y B32 arman su texto con TEXT(...;"0.00"), cuyo separador decimal
# depende del idioma del Excel instalado (en un Excel en español "1,79 m IGN"
# sale como "002 m IGN"). Por eso esos dos valores se leen como número desde la
# hoja Calculo en vez de tomar el texto ya armado.
OUT_LECTURA_TEXTO = {
    "dia_maximo":        "B30",
    "estado_mas_severo": "B31",
    "ejecutiva":         "B33",
}
RANGO_NIVEL_FINAL = "L10:L16"   # Calculo: H final de cada día (m IGN)
RANGO_EXCESO = "U10:U16"        # Calculo: exceso sobre cota crítica (cm)

# --- Variables internas (hoja "Calculo"), las que el panel muestra como informativas ---
CELL_P5D = "B10"   # P5d antecedente acumulada (mm)
CELL_CER = "C10"   # CER aplicado el día 1 (cm/mm)

SIN_DESCARGA_SI = "SÍ"   # debe coincidir EXACTO con la validación del Excel
SIN_DESCARGA_NO = "NO"


# ----------------------------------------------------------------------------
# Utilidades
# ----------------------------------------------------------------------------
def jsonable(v):
    """Convierte lo que devuelve COM en algo serializable a JSON."""
    if v is None:
        return None
    if isinstance(v, (datetime.datetime, datetime.date)):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, (int, float, str, bool)):
        return v
    # pywintypes.Time y cualquier otra cosa rara
    try:
        return float(v)
    except (TypeError, ValueError):
        return str(v)


def num(valor, nombre, errs, minimo=None):
    """Valida un número y lo acumula en `errs` si falla."""
    try:
        x = float(valor)
    except (TypeError, ValueError):
        errs.append("%s: se esperaba un número." % nombre)
        return None
    if minimo is not None and x < minimo:
        errs.append("%s: no puede ser menor que %g." % (nombre, minimo))
        return None
    return x


# ----------------------------------------------------------------------------
# Motor Excel (una instancia viva durante toda la vida del servidor)
# ----------------------------------------------------------------------------
class ExcelEngine:
    def __init__(self, src_path):
        self.src_path = src_path
        # nombre temporal único por proceso: evita choques con un Excel huérfano
        self.tmp_path = os.path.join(
            tempfile.gettempdir(), "modelo_puertos_v4_%d.xlsx" % os.getpid()
        )
        self.xl = None
        self.wb = None
        self.ws = None
        self.wc = None
        self.wp = None
        self._job = None          # Job Object que ata el Excel a este proceso
        self._open()

    @staticmethod
    def _barrer_temporales_viejos():
        """Borra copias de trabajo que hayan quedado de corridas anteriores.

        Si el programa se cierra de golpe no llega a borrar la suya; con esto
        no se acumulan en la máquina. Las que estén en uso fallan y se saltean.
        """
        import glob
        patron = os.path.join(tempfile.gettempdir(), "modelo_puertos_v4_*.xlsx")
        for viejo in glob.glob(patron):
            try:
                os.remove(viejo)
            except OSError:
                pass   # en uso por otra instancia: no es asunto nuestro

    def _open(self):
        self._barrer_temporales_viejos()
        shutil.copy2(self.src_path, self.tmp_path)
        pythoncom.CoInitialize()
        # DispatchEx (y no Dispatch) fuerza una instancia de Excel propia:
        # si el usuario tiene Excel abierto, Dispatch se engancha a la suya,
        # se la oculta al arrancar y se la cierra al salir del servidor.
        self.xl = win32.DispatchEx("Excel.Application")
        self.xl.Visible = False
        self.xl.DisplayAlerts = False
        self._atar_excel_a_este_proceso()
        self.wb = self.xl.Workbooks.Open(self.tmp_path)
        self.ws = self.wb.Worksheets(SHEET)
        try:
            self.wc = self.wb.Worksheets(SHEET_CALC)
        except Exception:
            self.wc = None
        self.wp = self.wb.Worksheets(SHEET_PARAM)

    def _atar_excel_a_este_proceso(self):
        """Ata el Excel que acabamos de abrir a la vida de este programa.

        Lo mete en un Job Object de Windows con "matar al cerrar el job": si
        este proceso termina por cualquier vía —incluso cerrando la ventana
        con la X o desde el Administrador de tareas— Windows cierra ese Excel.
        Sin esto quedan procesos EXCEL.EXE invisibles acumulándose en la
        máquina del cliente.
        """
        try:
            import win32api, win32con, win32job, win32process

            _, pid = win32process.GetWindowThreadProcessId(self.xl.Hwnd)
            if not pid:
                return

            job = win32job.CreateJobObject(None, "")
            info = win32job.QueryInformationJobObject(
                job, win32job.JobObjectExtendedLimitInformation)
            info["BasicLimitInformation"]["LimitFlags"] |= \
                win32job.JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            win32job.SetInformationJobObject(
                job, win32job.JobObjectExtendedLimitInformation, info)

            proceso = win32api.OpenProcess(
                win32con.PROCESS_SET_QUOTA | win32con.PROCESS_TERMINATE, False, pid)
            win32job.AssignProcessToJobObject(job, proceso)
            self._job = job       # hay que conservar el handle: si se cierra, Excel muere
        except Exception:
            self._job = None      # si no se pudo, queda el cierre normal de close()

    def reload(self):
        """Vuelve a copiar el original (para tomar cambios del modelo) y reabre."""
        self.close()
        self._open()

    # -- escritura de entradas -------------------------------------------------
    def write_inputs(self, nivel, antecedentes, sin_descarga, pronostico):
        self.ws.Range(CELL_NIVEL).Value = float(nivel)

        for i, mm in enumerate(antecedentes):
            self.ws.Cells(ROW_ANTECEDENTE_0 + i, 2).Value = float(mm)

        self.ws.Range(CELL_SIN_DESCARGA).Value = (
            SIN_DESCARGA_SI if sin_descarga else SIN_DESCARGA_NO
        )

        for i, dia in enumerate(pronostico):
            fila = ROW_PRONOSTICO_0 + i
            self.ws.Cells(fila, 2).Value = float(dia["lluvia"])   # columna B
            self.ws.Cells(fila, 3).Value = float(dia["rio"])      # columna C

        self.xl.CalculateFull()

    # -- lectura de resultados -------------------------------------------------
    def read_outputs(self):
        out = {}
        for clave, celda in OUT_INDICADORES.items():
            out[clave] = jsonable(self.ws.Range(celda).Value)
        for clave, celda in OUT_PARAMETROS.items():
            out[clave] = jsonable(self.wp.Range(celda).Value)

        # variables internas informativas
        out["p5d_mm"] = jsonable(self.wc.Range(CELL_P5D).Value) if self.wc else None
        out["cer_inicial"] = jsonable(self.wc.Range(CELL_CER).Value) if self.wc else None

        # proyección de 7 días: B=lluvia, C=río, D=descarga, E=nivel, F=margen, G=estado
        fila_ini = ROW_PRONOSTICO_0
        fila_fin = ROW_PRONOSTICO_0 + DIAS_PRONOSTICO - 1
        bloque = self.ws.Range("A%d:G%d" % (fila_ini, fila_fin)).Value
        dias = []
        for fila in bloque:
            dias.append({
                "dia":            jsonable(fila[0]),
                "lluvia_mm":      jsonable(fila[1]),
                "rio_lujan":      jsonable(fila[2]),
                "descarga":       jsonable(fila[3]),
                "nivel_esperado": jsonable(fila[4]),
                "margen_cm":      jsonable(fila[5]),
                "estado":         jsonable(fila[6]),
            })
        out["dias"] = dias

        lectura = {
            clave: jsonable(self.ws.Range(celda).Value)
            for clave, celda in OUT_LECTURA_TEXTO.items()
        }
        lectura["nivel_maximo_m"] = self._max_columna(RANGO_NIVEL_FINAL)
        lectura["exceso_maximo_cm"] = self._max_columna(RANGO_EXCESO)
        limite = out.get("limite_modelo")
        lectura["fuera_de_rango"] = bool(
            lectura["nivel_maximo_m"] is not None
            and isinstance(limite, (int, float))
            and lectura["nivel_maximo_m"] > limite
        )
        out["lectura"] = lectura

        out["fecha"] = jsonable(self.ws.Range("B5").Value)
        return out

    def _max_columna(self, rango):
        """Máximo de una columna de la hoja Calculo, ignorando celdas vacías."""
        if self.wc is None:
            return None
        valores = []
        for fila in self.wc.Range(rango).Value:
            v = fila[0]
            if isinstance(v, (int, float)):
                valores.append(float(v))
        return max(valores) if valores else None

    def read_inputs(self):
        """Entradas tal como están hoy en el libro (sirve para precargar el panel)."""
        antecedentes = [
            jsonable(self.ws.Cells(ROW_ANTECEDENTE_0 + i, 2).Value)
            for i in range(DIAS_ANTECEDENTES)
        ]
        pronostico = []
        for i in range(DIAS_PRONOSTICO):
            fila = ROW_PRONOSTICO_0 + i
            pronostico.append({
                "lluvia": jsonable(self.ws.Cells(fila, 2).Value),
                "rio":    jsonable(self.ws.Cells(fila, 3).Value),
            })
        return {
            "nivel": jsonable(self.ws.Range(CELL_NIVEL).Value),
            "antecedentes": antecedentes,
            "sin_descarga": str(self.ws.Range(CELL_SIN_DESCARGA).Value or "").strip().upper() == SIN_DESCARGA_SI,
            "pronostico": pronostico,
        }

    def calculate(self, nivel, antecedentes, sin_descarga, pronostico):
        self.write_inputs(nivel, antecedentes, sin_descarga, pronostico)
        return self.read_outputs()

    def close(self):
        try:
            if self.wb is not None:
                self.wb.Close(SaveChanges=False)
        except Exception:
            pass
        try:
            if self.xl is not None:
                self.xl.Quit()
        except Exception:
            pass
        self.xl = self.wb = self.ws = self.wc = self.wp = None
        # Soltar el job cierra de prepo el Excel que hubiera quedado colgado.
        try:
            if self._job is not None:
                self._job.Close()
        except Exception:
            pass
        self._job = None
        try:
            if os.path.exists(self.tmp_path):
                os.remove(self.tmp_path)
        except Exception:
            pass


ENGINE = None  # se inicializa en main()


# ----------------------------------------------------------------------------
# Validación del payload
# ----------------------------------------------------------------------------
def parse_payload(payload):
    """Devuelve (datos, errores). `datos` es None si hay errores."""
    errs = []

    nivel = num(payload.get("nivel"), "Nivel actual del lago", errs, minimo=0)

    antecedentes = payload.get("antecedentes")
    ant = []
    if not isinstance(antecedentes, (list, tuple)) or len(antecedentes) != DIAS_ANTECEDENTES:
        errs.append("Precipitaciones antecedentes: se esperaban %d valores (Día -5 a Día -1)."
                    % DIAS_ANTECEDENTES)
    else:
        for i, mm in enumerate(antecedentes):
            v = num(mm, "Antecedente Día -%d" % (DIAS_ANTECEDENTES - i), errs, minimo=0)
            ant.append(v)

    pronostico = payload.get("pronostico")
    pron = []
    if not isinstance(pronostico, (list, tuple)) or len(pronostico) != DIAS_PRONOSTICO:
        errs.append("Pronóstico: se esperaban %d días." % DIAS_PRONOSTICO)
    else:
        for i, d in enumerate(pronostico):
            if not isinstance(d, dict):
                errs.append("Pronóstico Día %d: formato inválido." % (i + 1))
                continue
            lluvia = num(d.get("lluvia"), "Lluvia Día %d" % (i + 1), errs, minimo=0)
            rio = num(d.get("rio"), "Nivel Río Luján Día %d" % (i + 1), errs)
            pron.append({"lluvia": lluvia, "rio": rio})

    sin_descarga = payload.get("sin_descarga", False)
    if isinstance(sin_descarga, str):
        sin_descarga = sin_descarga.strip().upper() in ("SÍ", "SI", "TRUE", "1")
    sin_descarga = bool(sin_descarga)

    if errs:
        return None, errs
    return {
        "nivel": nivel,
        "antecedentes": ant,
        "sin_descarga": sin_descarga,
        "pronostico": pron,
    }, []


# ----------------------------------------------------------------------------
# Servidor HTTP
# ----------------------------------------------------------------------------
class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # silencioso

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_json(self, code, obj):
        self._send(code, json.dumps(obj, ensure_ascii=False))

    def do_GET(self):
        if self.path in ("/", "/" + PAGE, "/index.html"):
            path = os.path.join(HERE, PAGE)
            try:
                with open(path, "rb") as f:
                    self._send(200, f.read(), "text/html; charset=utf-8")
            except FileNotFoundError:
                self._send(404, "%s no encontrado" % PAGE, "text/plain; charset=utf-8")
            return

        if self.path == "/model":
            try:
                self._send_json(200, {
                    "ok": True,
                    "inputs": ENGINE.read_inputs(),
                    "result": ENGINE.read_outputs(),
                })
            except Exception as e:
                self._send_json(500, {"error": str(e)})
            return

        self._send_json(404, {"error": "not found"})

    def do_POST(self):
        if self.path == "/reload":
            try:
                ENGINE.reload()
                self._send_json(200, {"ok": True, "msg": "Modelo recargado"})
            except Exception as e:
                self._send_json(500, {"error": str(e)})
            return

        if self.path != "/calculate":
            self._send_json(404, {"error": "not found"})
            return

        try:
            length = int(self.headers.get("Content-Length", 0))
            payload = json.loads(self.rfile.read(length) or b"{}")
        except Exception:
            self._send_json(400, {"error": "JSON inválido"})
            return

        datos, errs = parse_payload(payload)
        if errs:
            self._send_json(400, {"error": " ".join(errs)})
            return

        try:
            result = ENGINE.calculate(**datos)
            self._send_json(200, {"ok": True, "result": result})
        except Exception:
            # Si Excel murió, intentar reabrir una vez
            try:
                ENGINE.reload()
                result = ENGINE.calculate(**datos)
                self._send_json(200, {"ok": True, "result": result})
            except Exception as e2:
                self._send_json(500, {"error": "Falló el cálculo en Excel: %s" % e2})


def registrar_cierre_de_consola():
    """Cierra Excel y borra el temporal aunque cierren la ventana con la X."""
    def handler(evento):
        try:
            if ENGINE is not None:
                ENGINE.close()
        except Exception:
            pass
        return False   # dejar que Windows siga con el cierre

    try:
        import win32api
        win32api.SetConsoleCtrlHandler(handler, True)
    except Exception:
        pass   # si no se puede registrar, el finally sigue cubriendo Ctrl+C


def salir_con_mensaje(titulo, detalle):
    """Muestra un error legible y deja la ventana abierta para poder leerlo."""
    print("")
    print("=" * 66)
    print("  " + titulo)
    print("=" * 66)
    for linea in detalle:
        print("  " + linea)
    print("")
    try:
        input("  Presione ENTER para cerrar esta ventana...")
    except Exception:
        pass


def main():
    global ENGINE

    print("Panel Operativo Expeditivo - Puertos")
    print("Iniciando, aguarde unos segundos...")
    print("")

    if not os.path.exists(SRC_XLSX):
        salir_con_mensaje("No se encontró el modelo de cálculo", [
            "Falta el archivo:", "  %s" % os.path.basename(SRC_XLSX),
        ])
        return

    # 1) abrir Excel
    try:
        ENGINE = ExcelEngine(SRC_XLSX)
    except Exception as e:
        salir_con_mensaje("No se pudo iniciar Microsoft Excel", [
            "Este panel usa Excel como motor de cálculo, así que la",
            "computadora necesita tener Microsoft Excel instalado.",
            "",
            "Detalle técnico: %s" % e,
        ])
        return

    # 2) levantar el servidor local
    url = "http://%s:%d" % (HOST, PORT)
    try:
        httpd = socketserver.TCPServer((HOST, PORT), Handler)
    except OSError as e:
        ENGINE.close()
        salir_con_mensaje("El puerto %d está ocupado" % PORT, [
            "Puede que el panel ya esté abierto en otra ventana.",
            "Cierre la otra ventana y vuelva a intentar.",
            "",
            "Detalle técnico: %s" % e,
        ])
        return

    # Si el usuario cierra la ventana con la X, Windows mata el proceso sin
    # pasar por el finally: sin esto quedaría un Excel invisible dando vueltas.
    registrar_cierre_de_consola()

    with httpd:
        httpd.allow_reuse_address = True
        print("  Panel disponible en: %s" % url)
        print("")
        print("  Se abrirá solo en el navegador.")
        print("  IMPORTANTE: no cierre esta ventana mientras use el panel.")
        print("  Para terminar, cierre esta ventana.")
        print("")
        try:
            webbrowser.open(url)
        except Exception:
            print("  (No se pudo abrir el navegador: entre manualmente a %s)" % url)
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nCerrando...")
        finally:
            ENGINE.close()


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        salir_con_mensaje("El panel se detuvo por un error inesperado", [str(e)])
