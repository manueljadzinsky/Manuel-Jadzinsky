# -*- coding: utf-8 -*-
"""Arma el ejecutable del Panel Operativo Expeditivo.

Uso (en esta carpeta, con Python instalado):
    pip install pyinstaller
    python construir_exe.py

Deja el resultado en:  dist\\Panel Operativo Puertos.exe

El .exe lleva adentro el Excel del modelo y el HTML del panel, así que se
entrega un único archivo. Lo que NO lleva (ni puede llevar) es Microsoft
Excel: la PC del cliente tiene que tenerlo instalado, porque el cálculo lo
hace el propio libro.
"""

import os
import shutil
import subprocess
import sys
import tempfile

AQUI = os.path.dirname(os.path.abspath(__file__))
NOMBRE = "Panel Operativo Puertos"

XLSX = "Modelo_Simplificado_Evaluacion_Exposicion_Hidrica.xlsx"
HTML = "Panel_Puertos_V4.html"
ENTRADA = "backend_server.py"

for f in (XLSX, HTML, ENTRADA):
    if not os.path.exists(os.path.join(AQUI, f)):
        sys.exit("ERROR: falta %s" % f)

# Restos de intentos anteriores dentro de la carpeta del proyecto.
for carpeta in ("build", "dist"):
    shutil.rmtree(os.path.join(AQUI, carpeta), ignore_errors=True)
spec_viejo = os.path.join(AQUI, NOMBRE + ".spec")
if os.path.exists(spec_viejo):
    try:
        os.remove(spec_viejo)
    except OSError:
        pass

# Si el Excel esta abierto, PyInstaller no lo puede leer con open(), pero
# shutil.copy2 si. Por eso se copian los datos a una carpeta intermedia y el
# empaquetado se hace desde ahi: asi no hace falta cerrar Excel para construir.
STAGE = os.path.join(tempfile.gettempdir(), "panel_puertos_build")
shutil.rmtree(STAGE, ignore_errors=True)
os.makedirs(STAGE)
for f in (XLSX, HTML):
    try:
        shutil.copy2(os.path.join(AQUI, f), os.path.join(STAGE, f))
    except PermissionError:
        sys.exit("ERROR: no se pudo leer %s. Cerralo en Excel y volve a intentar." % f)
print("Datos preparados en: %s" % STAGE)
print("OJO: se empaqueta la ULTIMA VERSION GUARDADA del Excel.\n")

# PyInstaller trabaja fuera de OneDrive: si compila dentro de la carpeta
# sincronizada, OneDrive le bloquea archivos intermedios y la build falla.
WORK = os.path.join(tempfile.gettempdir(), "panel_puertos_work")
shutil.rmtree(WORK, ignore_errors=True)
os.makedirs(WORK)

cmd = [
    sys.executable, "-m", "PyInstaller",
    "--onefile",                 # un solo .exe, sin carpeta de dependencias
    "--console",                 # la ventana hace de "apagar": cerrarla detiene todo
    "--name", NOMBRE,
    "--add-data", "%s%s." % (os.path.join(STAGE, XLSX), os.pathsep),   # el modelo viaja adentro
    "--add-data", "%s%s." % (os.path.join(STAGE, HTML), os.pathsep),   # el panel tambien
    "--hidden-import", "win32timezone",
    "--hidden-import", "win32job",
    "--hidden-import", "win32process",
    "--workpath", os.path.join(WORK, "build"),
    "--distpath", os.path.join(WORK, "dist"),
    "--specpath", WORK,
    "--noconfirm",
    "--clean",
    os.path.join(AQUI, ENTRADA),
]

print("Construyendo... (tarda uno o dos minutos)\n")
res = subprocess.run(cmd, cwd=WORK)
if res.returncode != 0:
    sys.exit("La construccion fallo (codigo %d)" % res.returncode)

generado = os.path.join(WORK, "dist", NOMBRE + ".exe")
if not os.path.exists(generado):
    sys.exit("No se genero el .exe")

destino_dir = os.path.join(AQUI, "Entrega al cliente")
os.makedirs(destino_dir, exist_ok=True)
exe = os.path.join(destino_dir, NOMBRE + ".exe")
shutil.copy2(generado, exe)
shutil.rmtree(WORK, ignore_errors=True)
shutil.rmtree(STAGE, ignore_errors=True)

print("\nListo: %s" % exe)
print("Tamano: %.1f MB" % (os.path.getsize(exe) / (1024 * 1024)))
print("\nComprimi la carpeta 'Entrega al cliente' y mandala.")
